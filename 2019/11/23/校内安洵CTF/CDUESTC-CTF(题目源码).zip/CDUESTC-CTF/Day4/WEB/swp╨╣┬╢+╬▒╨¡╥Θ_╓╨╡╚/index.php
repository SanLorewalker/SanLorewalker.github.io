<?php
echo "<h2>I have a robot, it doesn't like ai, but it likes vi.</h2>";
if(!(isset($_GET['ai']) && isset($_GET['f']))){
    die();
}
else{
    $path = $_GET['ai'];
    $data = file_get_contents($path);
    if($data != "I want a flag!"){
        die("Don't you want it?");
    }
    $f=$_GET['f'];
    include($f);
}
?>