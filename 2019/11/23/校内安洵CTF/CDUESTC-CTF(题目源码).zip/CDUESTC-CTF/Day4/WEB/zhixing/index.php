<html>
  <head>
    <title>苹果专卖店</title>
  </head>
  <body>
    <?php
    error_reporting(0);
    highlight_file(__FILE__);
    $price = $_GET['price'];
    $here = 'echo $goods.'.'的价格是：'.$price.';';
    $sum = create_function('$goods', $here);
    $sum('iphone11');
    ?>
  </body>
</html>
