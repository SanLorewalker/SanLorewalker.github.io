<?php
echo "年轻人：等你买的起iphone11后，我再用flag跟你换！\n";
//flag{iphone11_is_very_expensive}
?>
<!-- Tips:flag在注释里面哦 -->
