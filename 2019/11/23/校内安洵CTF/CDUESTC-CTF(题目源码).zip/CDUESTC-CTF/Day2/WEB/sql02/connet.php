<?php  
    define('DB_HOST', 'localhost');  
    define('DB_USER', 'root1');  
    define('DB_PWD', '1728aceAB7');  
    define('DB_CHARSET', 'UTF8');  
    define('DB_DBNAME', 'web03');  
?>
