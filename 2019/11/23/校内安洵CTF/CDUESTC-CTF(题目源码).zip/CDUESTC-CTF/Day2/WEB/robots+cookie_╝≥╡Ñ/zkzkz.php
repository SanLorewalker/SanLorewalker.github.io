<?php
$ckck="flag{cookie-session is beautiful!}";
?>