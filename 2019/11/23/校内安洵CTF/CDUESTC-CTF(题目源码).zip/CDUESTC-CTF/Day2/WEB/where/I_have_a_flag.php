<meta charset="utf-8" http-equiv = "refresh"  content = "0.1;url=flag_is_not_here.php" />
<html><head>
<title>404 Not Found</title>
</head><body>
<!-- <h1>Not Found</h1>
<p>The requested URL /I_have_a_flag.php was not found on this server.</p>
flag={It_is_reAlly_imp0rtant_t0_bE_carefU1};-->
</body></html>
