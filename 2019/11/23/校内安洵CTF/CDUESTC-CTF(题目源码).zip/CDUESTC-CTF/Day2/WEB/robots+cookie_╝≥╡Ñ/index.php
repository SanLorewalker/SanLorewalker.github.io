<html>
<img src="coo.jpg" width="300" height="300">
<br/>
<?php
header("content-type:text/html;charset=utf-8");   
require("zkzkz.php");
echo "This kind of biscuit is my favorite!  \n";
if(isset($_COOKIE['margin']) && $_COOKIE['margin']=='cd6uestc'){ 
  echo '曲奇你好'.$ckck;
}
?>
</html>