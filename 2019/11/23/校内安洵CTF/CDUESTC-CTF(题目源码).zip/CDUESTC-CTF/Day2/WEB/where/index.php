<meta charset="utf-8" />
<html>
<head>
<title>where_is_flag</title>
</head>
<body>
<div align="center"><p> </p></div>
<div align="center"><p> </p></div>
<div align="center"><p> </p></div>
<div align="center"><img src='where.png' width='336' height='170'></img></div>
<div align="center"><p> </p></div>
<div align="center"><p> </p></div>
<div align="center"><a href="I_have_a_frog.php">Flag_is_here!</a></div>
<div align="center"><p> </p></div>
<div align="center"><p> </p></div>
<script language="javascript">
function disableRightClick(e)
{
   var message = "No Way!"
   if(!document.rightClickDisabled)
   {
  if(document.layers)
  {
    document.captureEvents(Event.MOUSED)
    document.onmousedown = disableRightClick;
  }
  else document.oncontextmenu = disableRightClick;
  return document.rightClickDisabled = true;
   }
   if(document.layers || (document.getElementById && !document.all))
   {
  if (e.which==2||e.which==3)
  {
    alert(message);
    return false;
  }
   }
   else
   {
  alert(message);
  return false;
   }
}
disableRightClick();
</script>
</body>
</html>
