<?php
highlight_file('baby_Magic.php');
error_reporting(0);
$Baby= $_GET["Baby"];
echo $Baby;
$love = $_GET["love"];
if(!isset($Baby)){
    echo 'Baby you are so good '.'<br>';
}
if(preg_match("/flag/",$Baby)){
    die('Baby can no not hack me' );
}
if(preg_match("/etc/",$Baby)){
    die('Baby can no not hack me' );
}
$s='etc|root|bin|home|boot|var|usr|tmp|run|opt';
if(preg_match($s,$Baby)){
    die('Baby can no not hack me' );
}
include($Baby);
if(isset($love)){
    $url = parse_url($_SERVER['REQUEST_URI']);
    parse_str($url['query'],$query);
    foreach($query as $value){
        if (preg_match("/flag/",$value)) {
            die('Baby do not hit me');
            exit();
        }
    }
    $love = unserialize($love);
}else{
    echo "Baby you can't give me Love";
}
?>