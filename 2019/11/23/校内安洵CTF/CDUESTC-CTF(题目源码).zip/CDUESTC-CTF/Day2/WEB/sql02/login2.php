﻿<?php
error_reporting(0); 
//$id = substr($_SERVER["QUERY_STRING"],3);
$id = $_POST['id'];
$contact=array('\'','%20',' ','--','%27','and','or','And','aNd','anD','ANd','AnD','aND','AND','Or','oR','+');
$f = null;
require_once "connet.php";
require_once 'mysqlconfig.php';
$ma1=new DB();
$link=$ma1->connect();
/*for ($i=0;$i<count($contact);$i++) {
	//$id=str_replace($contact[$i], '', $id);
	if(strpos($id,$contact[$i])!== false){
		echo  "<h2>没事干也不要搞人家后台呀！</h2>";
		$f = false;
		break;
	}
}*/
$f = $ma1->mark($id);
//echo $id;
//echo $f;
if($f!=$id){
	//echo $id;
	//echo $f;
	echo "<p>没事不要搞人家后台呀！多耍朋友！！！</p>";
}else{
	if($f!=null){
	/**for ($i=0;$i<count($contact);$i++) {
		$id=str_replace($contact[$i], '', $id);
	}*/

	$sql = "select * from user where id = (" . $f . ")";
	//echo $sql;
	$res=$ma1->selectf($link,$sql);
	if($res){
	    echo "HELLO：".$res['username'];
	}else{
	    echo  "<p>搞什么？这个人不见了!</p>";
	};
	}else{
		echo "<p>没事不要搞人家后台呀！多耍朋友！！！</p>";
	}
}

?>