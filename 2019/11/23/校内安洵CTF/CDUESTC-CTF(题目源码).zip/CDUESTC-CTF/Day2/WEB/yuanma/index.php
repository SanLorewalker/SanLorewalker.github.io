﻿<html>
  <head>
    <title>是码不是马</title>
  </head>
  <body>
    <?php
    error_reporting(0);
    if("admin"===$_GET[user]) {
      echo("<p>弟弟，你做的还不够!</p>");
      exit();
    }

    $_GET[user] = urldecode($_GET[user]);
    if($_GET[user] == "admin")
    {
      echo "<p>欢迎欢迎!</p>";
      echo "<p>flag{uR1dec0de_1s_vEry_pracTica1!}</p>";
    }

    echo "你能看到我的源码";
    echo "<img src='1.png' width='30' height='30'>";
    echo "?\n";
    ?>
  </body>
</html>
