<?php
if(isset($_POST['Baby'])){
    header("hint:baby1.txt");
    echo'sorry Baby I can not give you any more                               ';
    $dd=$_POST['Baby'];
    unserialize($dd);
}
else{
    echo 'you can give me a Baby from postdata';
}
class Hint
{
    public $a;
    public $b;
    public $c = 'baby_Magic.php&&Gay.php';

    function __wakeup()
    {
        $this->b='mylove';
        if($this->b=trim($this->a,'NO')){
            echo $this->c;
        }
    }

    function __construct($love)
    {
        echo $this->a = $love;
    }
}
?>

