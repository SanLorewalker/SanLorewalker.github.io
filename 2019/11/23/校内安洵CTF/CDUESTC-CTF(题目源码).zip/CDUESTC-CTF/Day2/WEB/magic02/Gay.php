<?php
class Mygirl{
    private $mygirl;
    private $goodboy;
    public $goodfriend;
    public $gayyou;
    public $gayme;
    public function __wakeup(){
        foreach(get_object_vars($this) as $b => $v) {
            $this->$b = null;
        }
        echo "Baby you should wakeup\n";
    }
    public function __construct($mygirl,$goodboy,$goodfriend) {
        $this->goodfriend=$goodfriend;
        $this->mygirl = $mygirl;
        $this->goodboy = $goodboy;

            }

    public function __destruct(){
        if($this->goodboy='Nolan'){
            $this->gayme='s1836677006a';
            $this->gayyou=$this->goodfriend;
            if($this->gayyou!=$this->gayme) {
                if (md5($this->gayme) == md5($this->gayyou)) {
                    $this->mygirl->Flagcome();}
                }
            }

    }
    public function clac($md5){
        $this->gayme=$md5;


    }
}

class Gayme{
    public $pleas;
    public $Gay;
    public $me;

    function __construct($pleas){
        $this->pleas = $pleas;
        $this->Gay = $this->me = 'Baby I love you';
    }

    public function Flagcome(){
        $this->Gay = 'But I love my cat Baby';
        if($this->Gay === $this->me)
        {
            if(isset($this->pleas)){
                echo @highlight_file($this->pleas,true);
            }
        }
    }
}
?>