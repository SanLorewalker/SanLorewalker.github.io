<?php
   class DB{
   	function connect(){
           $link = mysqli_connect(DB_HOST,DB_USER,DB_PWD);//连接数据库
           mysqli_set_charset($link,DB_CHARSET);//设置数据库字体格式
           mysqli_select_db($link,DB_DBNAME) or die('数据库打开失败');//选择数据库
          if(mysqli_connect_errno()){
			die('数据库连接失败 : '.mysqli_connect_errno());
		  }
          return $link;
    }


    function register($link,$sql){
      if (mysqli_query($link, $sql)) { 
          return true;
      } else { 
          return false;
      }
    }

    function login($link,$sql){
      $result = mysqli_query($link,$sql);
      $row = mysqli_num_rows($result);
      if($row !=0){
        return true;
      }else{
        return false;
      }
    }

    function selectf($link,$sql){
      $result = mysqli_query($link,$sql);
      $res = mysqli_fetch_array($result);
      return $res;
    }
	  //过滤sql注入关键字
    function mark($str){
        if (empty($str)) return false;
        $str = htmlspecialchars($str);
        //$str = str_replace( '/', "", $str);
        $str = str_replace( '"', "", $str);
        //$str = str_replace( '(', "", $str);
        //$str = str_replace( ')', "", $str);
        $str = str_replace( 'CR', "", $str);
        $str = str_replace( 'ASCII', "", $str);
        $str = str_replace( 'ASCII 0x0d', "", $str);
        $str = str_replace( 'LF', "", $str);
        $str = str_replace( 'ASCII 0x0a', "", $str);
        //$str = str_replace( ',', "", $str);
        $str = str_replace( '%', "", $str);
        $str = str_replace( ';', "", $str);
        $str = str_replace( 'eval', "", $str);
        $str = str_replace( 'open', "", $str);
        $str = str_replace( 'sysopen', "", $str);
        $str = str_replace( 'system', "", $str);
        $str = str_replace( '$', "", $str);
       // $str = str_replace( "'", "", $str);
       // $str = str_replace( "'", "", $str);
        $str = str_replace( 'ASCII 0x08', "", $str);
        $str = str_replace( '"', "", $str);
        $str = str_replace( '"', "", $str);
        $str = str_replace("", "", $str);
        $str = str_replace("&gt", "", $str);
        $str = str_replace("&lt", "", $str);
        $str = str_replace("<SCRIPT>", "", $str);
        $str = str_replace("</SCRIPT>", "", $str);
        $str = str_replace("<script>", "", $str);
        $str = str_replace("</script>", "", $str);
        //$str = str_replace("select","",$str);
        $str = str_replace("join","",$str);
        $str = str_replace("union","",$str);
        $str = str_replace("where","",$str);
        $str = str_replace("insert","",$str);
        $str = str_replace("delete","",$str);
        $str = str_replace("update","",$str);
        $str = str_replace("like","",$str);
        $str = str_replace("drop","",$str);
        $str = str_replace("DROP","",$str);
        $str = str_replace("create","",$str);
        $str = str_replace("modify","",$str);
        $str = str_replace("rename","",$str);
        $str = str_replace("alter","",$str);
        $str = str_replace("cas","",$str);
        $str = str_replace("&","",$str);
        $str = str_replace(">","",$str);
        $str = str_replace("<","",$str);
        $str = str_replace(" ",chr(32),$str);
        $str = str_replace(" ",chr(9),$str);
        $str = str_replace("    ",chr(9),$str);
        $str = str_replace("&",chr(34),$str);
        $str = str_replace("'",chr(39),$str);
        $str = str_replace("<br />",chr(13),$str);
        $str = str_replace("''","'",$str);
        $str = str_replace("css","'",$str);
        $str = str_replace("CSS","'",$str);
        $str = str_replace("<!--","",$str);
        $str = str_replace("convert","",$str);
        $str = str_replace("md5","",$str);
        $str = str_replace("passwd","",$str);
        $str = str_replace("password","",$str);
        $str = str_replace("../","",$str);
        $str = str_replace("./","",$str);
        $str = str_replace("Array","",$str);
        $str = str_replace("or 1='1'","",$str);
        $str = str_replace(";set|set&set;","",$str);
        $str = str_replace("`set|set&set`","",$str);
        $str = str_replace("--","",$str);
        $str = str_replace("OR","",$str);
        $str = str_replace("or","",$str);
        $str = str_replace('"',"",$str);
        //$str = str_replace("*","",$str);
        $str = str_replace("-","",$str);
        $str = str_replace("+","",$str);
        //$str = str_replace("/","",$str);
       // $str = str_replace("=","",$str);
        $str = str_replace("'/","",$str);
        $str = str_replace("-- ","",$str);
        $str = str_replace(" -- ","",$str);
        $str = str_replace(" --","",$str);
        //$str = str_replace("(","",$str);
        //$str = str_replace(")","",$str);
        $str = str_replace("{","",$str);
        $str = str_replace("}","",$str);
        //$str = str_replace(".","",$str);
        $str = str_replace("response","",$str);
        $str = str_replace("write","",$str);
        $str = str_replace("|","",$str);
        $str = str_replace("`","",$str);
        $str = str_replace(";","",$str);
        $str = str_replace("etc","",$str);
        $str = str_replace("root","",$str);
        $str = str_replace("//","",$str);
        $str = str_replace("!=","",$str);
        $str = str_replace("$","",$str);
        $str = str_replace("&","",$str);
        $str = str_replace("&&","",$str);
        $str = str_replace("==","",$str);
        //$str = str_replace("#","",$str);
        $str = str_replace("@","",$str);
        $str = str_replace("mailto:","",$str);
        $str = str_replace("CHAR","",$str);
        $str = str_replace("char","",$str);
        return $str;
    }
}
?>
