create database web03;
use web03;
DROP TABLE IF EXISTS `flagtxt`;
CREATE TABLE `flagtxt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FLAG` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flagtxt
-- ----------------------------
INSERT INTO `flagtxt` VALUES ('1', 'flag{QQ_158rtYF}');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('3', 'Alice', '123456');
INSERT INTO `user` VALUES ('4', 'Bob', '123456');
INSERT INTO `user` VALUES ('5', 'Colver', '123456');
INSERT INTO `user` VALUES ('6', 'DAILI', '123456');
