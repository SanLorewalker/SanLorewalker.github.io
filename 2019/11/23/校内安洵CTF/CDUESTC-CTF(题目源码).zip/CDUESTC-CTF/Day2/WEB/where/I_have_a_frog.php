<meta charset="utf-8" http-equiv = "refresh"  content = "0.1;url=I_have_a_flag.php" />
<html><head>
<title>404 Not Found</title>
</head><body>
<!-- <h1>Not Found</h1>
<p>The requested URL /I_have_a_flag.php was not found on this server.</p>
frog={Gua~gUa~guA~Gua~guA~gUa~}; -->
</body></html>
