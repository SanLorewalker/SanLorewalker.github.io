<?php
header("Content-type: text/html;charset=utf-8");
//error_reporting(0);



//设置上传目录
$UPLOAD_ADDR = "./upload_xx/";

?>