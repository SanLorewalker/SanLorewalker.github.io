<?php
echo 'Baby you are so good';
$flag='flag{I_love_you_my_baby_and_pleas_gay_me}';
?>