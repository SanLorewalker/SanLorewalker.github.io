<?php
highlight_file('easy_Magic.php');
include('flag.php');
/**this is flag.php
function getflag1(){
    echo $this->love;
}
function Tis(){
   echo "my baby can you give me mylove?";
}
}
$kiss=new Getflag();
*/
Class Baby{
    private $love='';
    function __wakeup()
    {
        $this->love='you have no input any';
        echo $this->love;
    }
    function __construct($love)
    {
        $this->love=$love;
    }
    function __destruct()
    {
        $you = $this->love;
        $who=new Getflag();
        $oh=$who->$you;
        echo $oh;

    }
}

if(isset($_GET['mylove'])){
    $mylove=$_GET['mylove'];
    unserialize($mylove);
}
else{
    $kiss->Tis();

}

?>