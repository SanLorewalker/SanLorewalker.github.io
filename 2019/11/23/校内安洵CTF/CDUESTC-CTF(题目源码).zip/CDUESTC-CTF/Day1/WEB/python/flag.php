<?php $flag="flag{Pyth0n_1S_N0T_pyth0n}";?>
