<?php
header("content-type:text/html;charset=utf-8");   
$con=mysqli_connect("127.0.0.1","root","cdklalala","cdctf");
if(!$con){die("error:".mysqli_connect_error());}

$id = $_GET['id'];

$query = "SELECT firstname, lastname FROM staff WHERE id = '$id';";
$res=mysqli_query($con,$query) or die( '<pre>' . ((is_object($con)) ? mysqli_error($con) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)) . '</pre>' );
$row = mysqli_fetch_assoc( $res );
if(isset($_GET['id'])){
  if($row!=0)
  {
    echo "<h2>恭喜你查询到员工：{$row["firstname"]}！</h2>";
    echo "<h3>该员工负责的是：key{{$row["lastname"]}}</h3>";
  }
  else
  {
    echo "还没查询到flag员工？flag员工缺岗啦？";
  }
}
else{
  echo "<h2>一个人都没有，难道今天所有员工罢工啦！！！</h2>";
  echo "<h3>赶紧用id点一下名！</h3>";
}
mysqli_close($con);   
?>