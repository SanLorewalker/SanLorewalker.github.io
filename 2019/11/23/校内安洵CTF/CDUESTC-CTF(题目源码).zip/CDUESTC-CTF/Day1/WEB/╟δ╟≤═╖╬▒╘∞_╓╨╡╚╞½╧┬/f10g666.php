<?php
$flag="flag{header's U_R_X is funny!}";
?>