<?php
class Getflag
{
    public $love = 'flag{baby_you_get_my_hear}';
    function getflag1(){
        echo $this->love;
    }
    function Tis(){
        echo "my baby can you give me mylove?";
    }
}
$kiss=new Getflag();

?>