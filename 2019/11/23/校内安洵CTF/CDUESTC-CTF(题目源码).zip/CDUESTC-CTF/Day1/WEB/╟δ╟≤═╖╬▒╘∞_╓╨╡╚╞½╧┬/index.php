<html>
<img src="zhao.jpg" width="300" height="300">
<br/>
<?php
header("content-type:text/html;charset=utf-8");   
require("f10g666.php");
if (isset($_SERVER['HTTP_USER_AGENT'])&&isset($_SERVER['HTTP_REFERER'])&&isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
    if ($_SERVER['HTTP_USER_AGENT']=='cduestc2.0' && $_SERVER['HTTP_REFERER']=='http://www.cduestc.cn' && $_SERVER['HTTP_X_FORWARDED_FOR']=='127.0.0.1'){
        echo '这才是我喜欢的那个它：'.$flag;
    }
    else{ echo "差一点，没填准确，是在'本地地址'、'cduestc2.0浏览器'、'http学校官网地址'这三个地方找哦！";}
}
else{
    echo "<h2>我喜欢不那么乖巧的它~</h2>";
	echo "<h3>那么我们开始寻找它：</h3>";
	echo "<h3>在本地上用我们学校的cduestc2.0浏览器，并从我们学校官网访问。</h3>";
}

?>
</html>