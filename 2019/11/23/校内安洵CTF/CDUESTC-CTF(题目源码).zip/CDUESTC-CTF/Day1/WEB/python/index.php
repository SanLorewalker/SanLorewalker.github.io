﻿
<?php #恭喜你终于发现了什么不同，赶紧写个脚本吧，不要妄图手工把这100行的代码读完.... ?>

<?php #不要试图手工读的... ?>

<?php #真的不要... ?>

<?php
#还没去写脚本？？？


#太狠了！
error_reporting(0);
$file=base64_decode(isset($_GET['FILE'])?$_GET['FILE']:"");















#说真的，宁不累吗？

$line=isset($_GET['LN'])?intval($_GET['LN']):0;


if($file=='') header("location:index.php?LN=0&FILE=ZmxhZy50eHQ=");


$file_list = array(
  '0' =>'flag.txt',
  '1' =>'index.php',
);



























#哥哥，我的脚本都写出来了，你的呢？？

if(isset($_COOKIE['Location']) && $_COOKIE['Location']=='Python'){
  $file_list[2]='flag.php';
}


















if(in_array($file, $file_list)){
  $fa = file($file);
  echo $fa[$line];
  echo "<br />";
}?>

<a href="index.php?LN=<?php echo $_GET['LN']+1;?>&FILE=ZmxhZy50eHQ="> 下一页 </a>

<?php #哥哥,我真的没有骗你，这个真的很长的....  ?>








<?php #哥哥,我真的没有骗你，这个真的很长的.... ?>



<?php #哥哥,我真的没有骗你，这个真的很长的.... ?>







