<?php
$a='easy_Magic.php';
echo $a;
?>