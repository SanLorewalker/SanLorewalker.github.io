<?php
header("content-type:text/html;charset=utf-8"); 
$servername = "localhost";
$username = "root";
$password = "cdklalala";

$con = mysqli_connect($servername, $username, $password);
if (!$con) {
    die("连接失败: " . mysqli_connect_error());
}
// 创建数据库
$sql = "CREATE DATABASE cdctf";
if (mysqli_query($con, $sql)) {
    echo "数据库创建成功";
} else {
    echo "Error creating database: " . mysqli_error($con);
}
mysqli_close($con);
//创建员工表
$dbname="cdctf";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("连接失败: " . mysqli_connect_error());
}

$sql2 = "CREATE TABLE staff (
id INT(10), 
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(50) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)";
if ($conn->query($sql2) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "创建数据表错误: " . $conn->error;
}
//
$sql3 = "INSERT INTO staff (id,firstname, lastname, email)
VALUES (1,'John', 'Script_kiddies', '159@qq.com');";
$sql3 .= "INSERT INTO staff (id,firstname, lastname, email)
VALUES (2,'Doe', 'exploit', '192@qq.com');";
$sql3 .= "INSERT INTO staff (id,firstname, lastname, email)
VALUES (3,'Mary', 'programmer', '146@qq.com');";
$sql3 .= "INSERT INTO staff (id,firstname, lastname, email)
VALUES (4,'Moe', 'operation_and_maintenance', '182@qq.com');";
$sql3 .= "INSERT INTO staff (id,firstname, lastname, email)
VALUES (5,'Julie', 'move_brick', '176@qq.com');";
$sql3 .= "INSERT INTO staff (id,firstname, lastname, email)
VALUES (6,'Dooley', 'percolation_test', '143@qq.com');";
$sql3 .= "INSERT INTO staff (id, firstname, lastname, email)
VALUES (7,'qing3389', 'mo_de_jie', 'qing@163.com')";

if (mysqli_query($conn, $sql3)) {
    echo "新记录插入成功";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>