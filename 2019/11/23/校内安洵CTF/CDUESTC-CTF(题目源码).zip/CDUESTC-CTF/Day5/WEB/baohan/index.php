﻿<!DOCTYPE HTML>
<html>

<?php
@session_start();
error_reporting(0);
?>

<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>云平台后台管理中心</title>
    <meta charset="UTF-8">
<script>#管理平台只有来自127.0.0.1的IP才可以访问哦~</script>
</head>

<body>
    <ul class="layui-nav">
        <li class="layui-nav-item layui-this"><a href="?page=index">云平台后台管理中心</a></li>
    </ul>
    <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
        <legend>设备列表</legend>
        <ol class="habit_rule" >
            <li><a href="?page=1">设备1号</a></li>
            <li><a href="?page=2">设备2号</a></li>
            <li><a href="?page=3">设备3号</a></li>
        </ol>
    </fieldset>

<br />

<?php

$page = $_GET[page];

if (isset($page)) {

if (ctype_alnum($page)) {
?>

    <br /><br /><br /><br />
    <div style="text-align:center">
        <p class="lead"><?php echo $page; ?></p>
    <br />

<?php

}else{

?>
        <br /><br /><br /><br />
        <div style="text-align:center">
            <p class="lead">
                <?php

                if (strpos($page, 'input') > 0) {
                    die();
                }

                if (strpos($page, 'ta:text') > 0) {
                    die();
                }

                if (strpos($page, 'text') > 0) {
                    die();
                }

                if ($page === 'index.php') {
                    die('Ok');
                }
                    include($page);
                    die();
                ?>
        </p>
        <br />

<--!为了方便管理员管理网站，内部人员可通过以下PHP代码规则访问此目录下的文件-->

<?php
$flag2="_Great";
}}
include("flag1.php");
if ($_SERVER['HTTP_X_FORWARDED_FOR'] === '127.0.0.1') {

    echo "Welcome My Admin ! Please include me in!\n";
    echo "$flag1";

    $pattern = $_GET[pat];
    $replacement = $_GET[rep];
    $subject = $_GET[sub];

    if (isset($pattern) && isset($replacement) && isset($subject)) {
        preg_replace($pattern, $replacement, $subject);
    }else{
        die();
    }
}
?>
</body>

</html>
