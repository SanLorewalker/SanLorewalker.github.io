<?php
error_reporting(0);
$exec = $_GET['exec'];


function sec()
{
    global $exec;
    foreach(get_defined_functions()['internal'] as $func_inter) {
        if (preg_match('/' . $func_inter . '/im', $exec)) {
            echo "Interesting, Try again" . "<br>";
            return true;
            break;
        }
    }
	$no = "time|na|nt|readfile|if|strlen|bin|hex|log";
	if (';' === preg_replace('/[a-z]+\((?R)?\)/', NULL, $exec)) {
		
		if (preg_match('/'.$no.'/i', $exec)) {	
			if (preg_match("/-|\+|~|\{|\}|\"|\|die|exit|eval|\[|\]|\\\|\*|`|/i", $exec)) {
			echo "Your are a Hacker!!!!" . "<br>";
			return true;
    }    
	
		}
    return false;
}
}

if(sec()==false){
	eval($exec);
}

highlight_file(__FILE__);
?>