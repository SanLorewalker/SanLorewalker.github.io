<?php
$flag1="flag1=flag{Y0u_HaVe";
?>
