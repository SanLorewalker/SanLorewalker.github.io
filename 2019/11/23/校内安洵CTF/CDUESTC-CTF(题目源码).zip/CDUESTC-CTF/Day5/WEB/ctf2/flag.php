<?php
$flag="flag{ni_shi_zhen_de_niu_bi}";
?>