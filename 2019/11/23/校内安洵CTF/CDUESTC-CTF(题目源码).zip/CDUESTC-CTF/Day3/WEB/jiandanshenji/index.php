<?php
  include "flag.php";
  highlight_file(__FILE__);

  if (isset($_GET['RMB'])) {
    $money=$_GET['RMB'];
    if ( $RMB>=9000 && $RMB<=9999 && strlen($RMB)==5 ) {
      echo "Here you are : $flag";
    }
    else {
      echo "Wrong Answer!";
    }
  }
  else {
    echo "You didn't give me any RMB!";
  }
?>
