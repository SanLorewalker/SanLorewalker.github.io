<?php
$flag="flag{Y0u_Deserve_1t}";
?>
