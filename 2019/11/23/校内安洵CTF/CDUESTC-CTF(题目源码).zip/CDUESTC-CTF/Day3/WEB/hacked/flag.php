<?php
$flag="flag{PreDecessorS_PLanted_TreeS}";
?>