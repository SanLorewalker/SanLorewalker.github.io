﻿<?php
//恭喜宝宝！！！

$a="flag{wordpress_Just_simple}";
?>